
function Constraints() {
}

module.exports = Constraints;