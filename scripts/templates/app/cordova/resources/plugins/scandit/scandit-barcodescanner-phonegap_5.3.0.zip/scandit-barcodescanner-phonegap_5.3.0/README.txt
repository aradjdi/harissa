Cross-Platform Barcode Scanner Plugin for Cordova/Phonegap
===========================================================

This archive contains the Scandit BarcodeScanner plugin for Cordova/Phonegap. Depending on your license, 
the plugins supports iOS, Android and Windows, or a combination of these platforms. To integrate the 
plugin into your application follow the instructions in our integration guide:

http://docs.scandit.com/stable/phonegap/cordova-integrate.html

Questions? Contact support@scandit.com.
