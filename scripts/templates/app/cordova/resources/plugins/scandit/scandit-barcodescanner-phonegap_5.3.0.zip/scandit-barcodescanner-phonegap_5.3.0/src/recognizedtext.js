function RecognizedText(text) {
	this.text = text;
	this.rejected = false;
}

module.exports = RecognizedText;
